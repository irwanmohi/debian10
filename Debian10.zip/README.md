# CYBERTIZE SETUP MANAGER

### **Cara guna:**
1. Log masuk ke VPS anda.
2. Masukkan perintah: `wget -O Debian10 "https://github.com/cybertize-dev/Debian-10/archive/refs/heads/main.zip"`
3. Pasang pakej unzip dengan cara: `apt-get -y install unzip`
4. Masukkan perintah: `unzip Debian10.zip`
5. Masuk ke dalam folder yang kamu baru saja unzip dengan cara masukkan perintah: `cd Debian10-main`
6. Masukkan perintah: `chmod +x configure && chmod +x install`
7. Jalankan script configure terlebih dahulu dengan cara masukkan perintah: `./configure`
8. Masukkan perintah: `./install` untuk senaraikan menu script

Stat | Packages / Services
------------ | -------------
:white_check_mark: | OpenSSH
:white_check_mark: | Dropbear
:white_check_mark: | OpenVPN
:white_check_mark: | Squid
:white_check_mark: | Stunnel
:white_check_mark: | SS-Libev
:white_check_mark: | Simple-OBFS
:white_check_mark: | BadVPN
:negative_squared_cross_mark: | V2Ray
:negative_squared_cross_mark: | Wireguard
:negative_squared_cross_mark: | Nginx
:white_check_mark: | Webmin
:white_check_mark: | Fail2Ban
:white_check_mark: | IpTables