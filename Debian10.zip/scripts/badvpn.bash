#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

wget -q "https://github.com/ambrop72/badvpn/archive/refs/tags/1.999.130.tar.gz" &>/dev/null
tar xzf 1.999.130.tar.gz && cd badvpn-1.999.130
cmake -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_TUN2SOCKS=1 -DBUILD_UDPGW=1
make install

mv /usr/local/bin/badvpn-udpgw /usr/sbin/
mv /usr/local/bin/badvpn-tun2socks /usr/sbin/

screen -AmdS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7300

# adding new rule on iptables for badvpn
iptables -A INPUT -p tcp --dport 7300 -m state --state NEW -j ACCEPT
iptables-save > /etc/iptables/iptables.rules

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with badvpn setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${CYAN}[ BADVPN DETAIL ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Status:${PLAIN} ${GREEN}Active & Enabled${PLAIN}"
echo -e "${YELLOW}Ipaddress:${PLAIN} ${GREEN}127.0.0.1${PLAIN}"
echo -e "${YELLOW}Ports:${PLAIN} ${GREEN}7300${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Check badvpn status with:${PLAIN}"
echo -e "${GREEN}systemctl status badvpn-udpgw${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""