#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

apt-get -y -qq install openvpn &>/dev/null
rm -r server &>/dev/null

cd /usr/share/easy-rsa
./easyrsa --batch init-pki &>/dev/null
./easyrsa --batch build-ca nopass &>/dev/null
./easyrsa --batch gen-dh &>/dev/null
./easyrsa --batch build-server-full server nopass &>/dev/null
cp -R /usr/share/easy-rsa/pki /etc/openvpn/

# /etc/openvpn/server.conf
{
  echo "# OVPN SERVER-CUSTOM CONFIG
# ----------------------------
port 5456
proto tcp
dev tun

ca /etc/openvpn/pki/ca.crt
cert /etc/openvpn/pki/issued/server.crt
key /etc/openvpn/pki/private/server.key
dh /etc/openvpn/pki/dh.pem

verify-client-cert none
server 10.8.0.0 255.255.255.0
ifconfig-pool-persist ipp.txt
push \"redirect-gateway def1 bypass-dhcp\"
push \"dhcp-option DNS 8.8.8.8\"
push \"dhcp-option DNS 8.8.4.4\"
keepalive 10 120
cipher AES-256-CBC
user nobody
group nogroup
persist-key
persist-tun
status status.log
log ovpn.log
verb 3
mute 10
plugin /usr/lib/x86_64-linux-gnu/openvpn/plugins/openvpn-plugin-auth-pam.so login
username-as-common-name" > /etc/openvpn/server.conf
} &>/dev/null

# custom.ovpn - Custom client config file
{
  echo "# OVPN CLIENT-CUSTOM CONFIG
# ----------------------------
client
dev tun
proto tcp
remote $ipaddr 5456
resolv-retry infinite
nobind
persist-key
persist-tun
remote-cert-tls server
cipher AES-256-CBC
auth SHA256
verb 3
auth-user-pass

;http-proxy-retry
;http-proxy $ipaddr 3128
;http-proxy-option CUSTOM-HEADER Protocol HTTP/1.1
;http-proxy-option CUSTOM-HEADER Host HOSTNAME" > /etc/openvpn/client/custom.ovpn

echo "" >> /etc/openvpn/client/custom.ovpn
echo "<ca>" >> /etc/openvpn/client/custom.ovpn
cat /etc/openvpn/pki/ca.crt >> /etc/openvpn/client/custom.ovpn
echo "</ca>" >> /etc/openvpn/client/custom.ovpn
} &>/dev/null

# stunnel.ovpn - Tls client config file
{
  echo "# OVPN CLIENT-TLS CONFIG
# ----------------------------
client
dev tun
proto tcp
remote 127.0.0.1 6545
resolv-retry infinite
nobind
persist-key
persist-tun
remote-cert-tls server
cipher AES-256-CBC
auth SHA256
verb 3
auth-user-pass

;http-proxy-retry
;http-proxy $ipaddr 3128
;http-proxy-option CUSTOM-HEADER Protocol HTTP/1.1
;http-proxy-option CUSTOM-HEADER Host HOSTNAME" > /etc/openvpn/client/stunnel.ovpn

echo "" >> /etc/openvpn/client/stunnel.ovpn
echo "<ca>" >> /etc/openvpn/client/stunnel.ovpn
cat /etc/openvpn/pki/ca.crt >> /etc/openvpn/client/stunnel.ovpn
echo "</ca>" >> /etc/openvpn/client/stunnel.ovpn
} &>/dev/null

iptables -A INPUT -p tcp --dport 5456 -m state --state NEW -j ACCEPT
iptables -A INPUT -p tcp --dport 6545 -m state --state NEW -j ACCEPT
iptables-save > /etc/iptables/iptables.rules

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with openvpn setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${PURPLE}[ OPENVPN DETAILS ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Service:${PLAIN} ${GREEN}Active & Enabled${PLAIN}"
echo -e "${YELLOW}Ipaddress:${PLAIN} ${GREEN}$ipaddr${PLAIN}"
echo -e "${YELLOW}Hostname:${PLAIN} ${GREEN}cybertize.tk${PLAIN}"
echo -e "${YELLOW}Config:${PLAIN} ${GREEN}5456${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Check openvpn status with:${PLAIN}"
echo -e "${GREEN}systemctl status openvpn@server${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""