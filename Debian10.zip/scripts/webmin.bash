#!/usr/bin/env bash

ALAMATIP=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )
ALAMATHOS=$( cat /etc/hostname )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

{
  wget -qO - http://www.webmin.com/jcameron-key.asc | sudo apt-key add -
  echo "deb http://download.webmin.com/download/repository sarge contrib" > /etc/apt/sources.list.d/webmin.list
} &>/dev/null

apt-get -qq update &>/dev/null
apt-get -y -qq install webmin &>/dev/null

iptables -A INPUT -p tcp --dport 10000 -m state --state NEW -j ACCEPT
iptables-save > /etc/iptables/iptables.rules

echo ""
echo -e "${GREEN}Congratulation, we are done with webmin setup${PLAIN}"
echo ""
echo "=============================================="
echo -e "${CYAN}[ WEBMIN DETAIL ]${PLAIN}"
echo "----------------------------------------------"
echo -e "${YELLOW}Status:${PLAIN} ${GREEN}Active & Enabled${PLAIN}"
echo -e "${YELLOW}Hostname:${PLAIN} ${GREEN}$ALAMATHOS${PLAIN}"
echo -e "${YELLOW}Ipaddress:${PLAIN} ${GREEN}$ALAMATIP${PLAIN}"
echo -e "${YELLOW}Ports:${PLAIN} ${GREEN}10000${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${GREEN}systemctl start webmin${PLAIN}"
echo -e "${GREEN}systemctl enable webmin${PLAIN}"
echo "=============================================="
