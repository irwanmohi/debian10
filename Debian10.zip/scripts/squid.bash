#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

apt-get -y -qq install squid &>/dev/null

# /etc/squid/squid.conf
echo "# CYBERTIZE SQUID CONFIG
# ----------------------------
acl localnet src 10.0.0.0/8
acl localnet src 172.16.0.0/12
acl localnet src 192.168.0.0/16

acl SSL_ports port 443
acl Safe_ports port 80
acl Safe_ports port 21
acl Safe_ports port 443
acl Safe_ports port 70
acl Safe_ports port 210
acl Safe_ports port 1025-65535
acl Safe_ports port 280
acl Safe_ports port 488
acl Safe_ports port 591
acl Safe_ports port 777
acl CONNECT method CONNECT
acl cybertize dst $ipaddr/24

http_access allow cybertize
http_access allow localnet
http_access allow localhost
http_access allow manager localhost
http_access deny manager
http_access deny all

http_port 3128
http_port 2426

cache deny all
access_log none
cache_store_log none
cache_log /dev/null
hierarchy_stoplist cgi-bin ?

refresh_pattern ^ftp: 1440 20%	10080
refresh_pattern ^gopher: 1440 0% 1440
refresh_pattern -i (/cgi-bin/|\?) 0	0% 0
refresh_pattern . 0	20%	4320
visible_hostname proxy.cybertize.tk" > /etc/squid/squid.conf

iptables -A INPUT -p tcp --dport 2426 -m state --state NEW -j ACCEPT
iptables -A INPUT -p tcp --dport 3128 -m state --state NEW -j ACCEPT
iptables-save > /etc/iptables/iptables.rules

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with squid setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${PURPLE}[ SQUID DETAIL ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Status:${YELLOW} ${GREEN}Started & Enabled${PLAIN}"
echo -e "${YELLOW}Ipaddress:${YELLOW} ${GREEN}$ipaddr${PLAIN}"
echo -e "${YELLOW}Ports:${YELLOW} ${GREEN}3128 & 2426(TLS)${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${GREEN}systemctl start squid${PLAIN}"
echo -e "${GREEN}systemctl enable squid${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""