#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

apt-get -y -qq install fail2ban &>/dev/null

cp /etc/fail2ban/fail2ban.conf /etc/fail2ban/fail2ban.conf.bak
cp /etc/fail2ban/jail.conf /etc/jail/jail.local

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with fail2ban setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${PURPLE}[ FAIL2BAN DETAIL ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Status:${PLAIN} ${GREEN}Active & Enabled${PLAIN}"
echo -e "${YELLOW}Configs:${PLAIN} ${GREEN}fail2ban.conf & jail.local${PLAIN}"
echo -e "${YELLOW}Action:${PLAIN} ${GREEN}action.d/*${PLAIN}"
echo -e "${YELLOW}Filter:${PLAIN} ${GREEN}filter.d/*${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Check fail2ban status with:${PLAIN}"
echo -e "${GREEN}systemctl status fail2ban${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""