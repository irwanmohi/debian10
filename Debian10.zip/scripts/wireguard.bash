#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

apt-get -qq update &>/dev/null
apt-get -y -qq install -t buster-backports wireguard &>/dev/null

wg genkey | tee /etc/wireguard/server_private.key | wg pubkey | tee /etc/wireguard/server_public.key &>/dev/null
# wg genkey | tee /etc/wireguard/client_private.key | wg pubkey | tee /etc/wireguard/client_public.key &>/dev/null

server_private_key=$( cat /etc/wireguard/server_private.key )
server_public_key=$( cat /etc/wireguard/server_public.key )
# client_private_key=$( cat /etc/wireguard/client_private.key )
# client_public_key=$( cat /etc/wireguard/client_public.key )

# PrivateKey = /etc/wireguard/server_private.key
# PublicKey = /etc/wireguard/client_public.key
echo "[Interface]
Address = 10.32.0.0/24
ListenPort = 51820
PrivateKey = cD+ZjXiVIX+0iSX1PNijl4a+88lCbDgw7kO78oXXLEc=

[Peer]
PublicKey = AYQJf6HbkQ0X0Xyt+cTMTuJe3RFwbuCMF46LKgTwzz4=
AllowedIPs = 10.32.0.1/32" > /etc/wireguard/wg0.conf

chmod 600 -R /etc/wireguard/

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with wireguard setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${CYAN}[ WIREGUARD DETAIL ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Status:${PLAIN} ${GREEN}Active & Enabled${PLAIN}"
echo -e "${YELLOW}Hostname:${PLAIN} ${GREEN}cybertize.tk${PLAIN}"
echo -e "${YELLOW}Ipaddress:${PLAIN} ${GREEN}$ipaddr${PLAIN}"
echo -e "${YELLOW}Port:${PLAIN} ${GREEN}10000${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${GREEN}systemctl start wg-quick@wg0.service${PLAIN}"
echo -e "${GREEN}systemctl enable wg-quick@wg0.service${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""

# client config
# [Interface]
# Address = 10.10.10.2/24
# DNS = 10.10.10.1
# PrivateKey = cOFA+x5UvHF+a3xJ6enLatG+DoE3I5PhMgKrMKkUyXI=

# [Peer]
# PublicKey = kQvxOJI5Km4S1c7WXu2UZFpB8mHGuf3Gz8mmgTIF2U0=
# AllowedIPs = 0.0.0.0/0
# Endpoint = 12.34.56.78:51820
# PersistentKeepalive = 25

# chmod 600 /etc/wireguard/ -R

## Address: Specify the private IP address of the VPN client.
## DNS: specify 10.10.10.1 (the VPN server) as the DNS server. It will be configured via the resolvconf command. You can also specify multiple DNS servers for redundancy like this: DNS = 10.10.10.1 8.8.8.8
## PrivateKey: The client’s private key, which can be found in the /etc/wireguard/client_private.key file on the client computer.
## PublicKey: The server’s public key, which can be found in the /etc/wireguard/server_public.key file on the server.
## AllowedIPs: 0.0.0.0/0 represents the whole Internet, which means all traffic to the Internet should be routed via the VPN.
## Endpoint: The public IP address and port number of VPN server. Replace 12.34.56.78 with your server’s real public IP address.
## PersistentKeepalive: Send an authenticated empty packet to the peer every 25 seconds to keep the connection alive. If PersistentKeepalive isn’t enabled, the VPN server might not be able to ping the VPN client.



# [Interface]
# Address = 10.10.10.1/24
# PrivateKey = UIFH+XXjJ0g0uAZJ6vPqsbb/o68SYVQdmYJpy/FlGFA=
# ListenPort = 51820

# [Peer]
# PublicKey = 75VNV7HqFh+3QIT5OHZkcjWfbjx8tc6Ck62gZJT/KRA=
# AllowedIPs = 10.10.10.2/32

# [Peer]
# PublicKey = YYh4/1Z/3rtl0i7cJorcinB7T4UOIzScifPNEIESFD8=
# AllowedIPs = 10.10.10.3/32

# [Peer]
# PublicKey = EVstHZc6QamzPgefDGPLFEjGyedJk6SZbCJttpzcvC8=
# AllowedIPs = 10.10.10.4/32