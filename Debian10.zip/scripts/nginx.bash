#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

apt-get -qq update &>/dev/null
apt-get -y -qq install nginx &>/dev/null

chown -R www-data:www-data /usr/share/nginx/html/