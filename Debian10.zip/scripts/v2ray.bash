#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )

if [ "$EUID" -ne 0 ]; then
  echo -e "[${RED}●${PLAIN}] Script needs to be run as root" && exit
fi

wget -O v2fly.zip "https://github.com/v2fly/fhs-install-v2ray/archive/refs/heads/master.zip"
unzip v2fly.zip && mv fhs-install-v2ray-master v2ray

export DAT_PATH='/usr/share/v2ray'
export JSON_PATH='/etc/v2ray'

cd v2ray && bash install-release.sh

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with v2ray setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${CYAN}[ V2RAY DETAIL ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Status:${PLAIN} ${GREEN}Started & Enabled${PLAIN}"
echo -e "${YELLOW}Hostname:${PLAIN} ${GREEN}cybertize.tk${PLAIN}"
echo -e "${YELLOW}Ipaddress:${PLAIN} ${GREEN}$ipaddr${PLAIN}"
echo -e "${YELLOW}Ports:${PLAIN} ${GREEN}10000${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${GREEN}systemctl start wg-quick@wg0.service${PLAIN}"
echo -e "${GREEN}systemctl enable wg-quick@wg0.service${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""