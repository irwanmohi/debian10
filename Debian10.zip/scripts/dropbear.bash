#!/usr/bin/env bash

ipaddr=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )
hname=$( cat /etc/hostname )

DEBIAN_FRONTEND=noninteractive apt-get -y -qq install dropbear &>/dev/null

# /etc/default/dropbear
echo 'NO_START=0
DROPBEAR_PORT=5968
DROPBEAR_EXTRA_ARGS="-p 8695"
DROPBEAR_BANNER="/etc/issue.net"
DROPBEAR_RSAKEY="/etc/dropbear/dropbear_rsa_host_key"
DROPBEAR_DSSKEY="/etc/dropbear/dropbear_dss_host_key"
DROPBEAR_ECDSAKEY="/etc/dropbear/dropbear_ecdsa_host_key"
DROPBEAR_RECEIVE_WINDOW=65536' > /etc/default/dropbear

# adding new rule on iptables for dropbear
iptables -A INPUT -p tcp --dport 5968 -m state --state NEW -j ACCEPT
iptables -A INPUT -p tcp --dport 8695 -m state --state NEW -j ACCEPT
iptables-save > /etc/iptables/iptables.rules

echo ""
echo ""
echo -e "${GREEN}Congratulation, we are done with dropbear setup${PLAIN}"
echo ""
echo -e "${CYAN}==============================================${PLAIN}"
echo -e "${PURPLE}[ DROPBEAR DETAIL ]${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Status:${PLAIN} ${GREEN}Active & Enabled${PLAIN}"
echo -e "${YELLOW}Ipaddress:${PLAIN} ${GREEN}$ipaddr${PLAIN}"
echo -e "${YELLOW}Hostname:${PLAIN} ${GREEN}$hname${PLAIN}"
echo -e "${YELLOW}Ports:${PLAIN} ${GREEN}5968 & 8695(TLS)${PLAIN}"
echo -e "${CYAN}----------------------------------------------${PLAIN}"
echo -e "${YELLOW}Check dropbear status with:${PLAIN}"
echo -e "${GREEN}systemctl status dropbear${PLAIN}"
echo -e "${CYAN}==============================================${PLAIN}"
echo ""
echo ""