#!/bin/bash
clear

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

ALAMATIP=$( ip -4 addr | sed -ne 's|^.* inet \([^/]*\)/.* scope global.*$|\1|p' | head -1 )
NAMAPENGGUNA=$(</dev/urandom tr -dc A-Z | head -c5)
KATALALUAN=$(</dev/urandom tr -dc 0-9 | head -c5)
TEMPOHMASAAKTIF="1"

TARIKHLUPUT=$(date -d "$TEMPOHMASAAKTIF days" +"%Y-%m-%d")
useradd -e `date -d "$TEMPOHMASAAKTIF days" +"%Y-%m-%d"` -s /bin/false -M $NAMAPENGGUNA
echo -e "$KATALALUAN\n$KATALALUAN" | passwd $NAMAPENGGUNA &>/dev/null

echo "==================================="
echo "[TRIAL] Maklumat akaun pengguna"
echo "-----------------------------------"
echo "Alamat IP: $ALAMATIP" 
echo "Nama pengguna: $NAMAPENGGUNA"
echo "Kata laluan: $KATALALUAN"
echo "Tempoh aktif: $TEMPOHMASAAKTIF hari"
echo "Tarikh luput: $TARIKHLUPUT"
echo "-----------------------------------"
echo "Created by Doctype, Allright Reserved."
echo "==================================="