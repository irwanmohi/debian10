#!/bin/bash

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

read -p "[UNLOCK] Masukkan nama pengguna: " NAMAPENGGUNA
egrep "^$NAMAPENGGUNA" /etc/passwd &>/dev/null
if [ $? -ne 0 ]; then
  echo "Nama pengguna tidak ditemukan!" && exit 1
fi
passwd -u $NAMAPENGGUNA
echo "======================================"
echo "Berjaya buka kunci akaun pengguna."
echo "--------------------------------------"
echo "Created by Doctype, Allright Reserved."
echo "======================================"
