#!/bin/bash

echo ""
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo "|C| |Y| |B| |E| |R| |T| |I| |Z| |E|"
echo "+-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+ +-+"
echo ""

read -p "[DELETE] Masukkan nama pengguna: " NAMAPENGGUNA
egrep "^$NAMAPENGGUNA" /etc/passwd >/dev/null
if [ $? -ne 0 ]; then
    echo "Nama pengguna tidak ditemukan!"
    exit 1
fi

passwd -l $NAMAPENGGUNA
userdel -f $NAMAPENGGUNA

echo "======================================"
echo "Berjaya padam akaun pengguna."
echo "--------------------------------------"
echo "Created by Doctype, Allright Reserved."
echo "======================================"