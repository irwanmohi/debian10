#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "[ ● ] Script needs to be run as root" && exit
fi

SENARAIPENGGUNA=$( cat /usr/src/shadowsocks/.accounts | cut -d ' ' -f 2 )

for PENGGUNA in "${SENARAIPENGGUNA[@]}"
do
  TANGGALHARIINI=$( date +%s )
  TARIKHLUPUT=$( grep -w "$PENGGUNA" /usr/src/shadowsocks/.accounts | cut -d ' ' -f 9 )
  TARIKHLUPUTAKAUN=$( date -d "$TARIKHLUPUT" +%s )
  SEMAKTARIKHLUPUT=$(( ($TARIKHLUPUTAKAUN - $TANGGALHARIINI) / 86400 ))
  if [[ "$SEMAKTARIKHLUPUT" = "0" ]]; then
    sed -i "/$PENGGUNA/d" /usr/src/shadowsocks/.accounts &>/dev/null
    systemctl disable shadowsocks-libev-server@$PENGGUNA-tls.service
    systemctl stop shadowsocks-libev-server@$PENGGUNA-tls.service
    systemctl disable shadowsocks-libev-server@$PENGGUNA-http.service
    systemctl stop shadowsocks-libev-server@$PENGGUNA-http.service

    rm /etc/shadowsocks-libev/$PENGGUNA-tls.json
    rm /etc/shadowsocks-libev/$PENGGUNA-http.json
  fi
done

echo "-----------------------------------------"
echo "Created by Doctype, Powered by Cybertize."
echo "========================================="